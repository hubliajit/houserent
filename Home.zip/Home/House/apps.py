from django.apps import AppConfig


class HouseConfig(AppConfig):
    name = 'House'
